# VICEBOUND conversion status

Updated: 2026-11-24

## Implemented in this working copy

- Application name and description changed to VICEBOUND.
- Main menu title and tagline changed; boot now enters the main menu instead of the missing-LFS intro video.
- Existing local save system and offline game systems retained.
- Provider-neutral monetization boundary and provisional Google Play product catalogue added.
- Provisional Android ARM64 APK export preset added (`com.aizudi.vicebound`), with debug signing enabled for test builds.
- GitHub Actions workflow added to fetch LFS/submodules, install Godot 4.6 + Android build dependencies, and export a debug APK artifact.
- Android touch overlay added to the in-game HUD:
  - Left virtual stick drives the existing move actions.
  - Right-side drag forwards relative look input to the existing camera input path.
  - Buttons map to existing fire, aim, jump, sprint, interact, reload, melee, phone, weapon-cycle and pause actions.
  - Minimap moves to the upper-left and is reduced on Android to free the lower-left movement area.
- Android selects the Godot Mobile renderer through the mobile renderer override. Android defaults to the Low graphics tier when no explicit or saved tier exists; mobile uses bilinear upscaling instead of the desktop FSR2 path.
- Desktop keyboard and gamepad action mappings are not replaced.

## Not implemented / not verified

- No AdMob Android plugin is integrated. No live ads can be served.
- No Google Play Billing plugin is integrated. No purchases can be initiated or verified.
- No backend purchase-token verification or signed offline entitlement cache exists.
- No final privacy policy, consent flow, store listing or Play Console product configuration exists.
- Touch controls have not been run on an Android device or Godot's input debugger. Static review found and fixed a camera-look gate: OrbitCamera and ChaseCamera now accept touch-generated relative mouse motion on mobile without changing desktop mouse-capture behaviour.
- Structural validation was executed locally on 2026-11-24 and passes 336 checks, including mobile camera-look gates and the Android Mobile renderer override. No Godot import, GDScript parser, unit, integration, performance or device test has run in this environment.
- No APK/AAB has been exported or signed.

## Hard blockers from the uploaded source archive

- 198 Git LFS pointer files stand in for binary assets. Their pointer metadata reports 707,178,848 bytes (674.42 MiB) of missing content. A path/hash/size inventory is included at `docs/VICEBOUND_LFS_MISSING_ASSETS.md`.
- `engine/godot-cpp` is an unpopulated Git submodule.
- The container has no Godot 4.6 executable, export templates, Android SDK, or Android build toolchain.
- Outbound network/DNS is unavailable in this build session, so the missing LFS objects, submodule, engine and SDK cannot be fetched here.
- GitHub App installation and repository write access were verified on 2026-11-24. The remote branch `vicebound/android-foundation` was created and a handoff file was committed. The complete local source delta (50 new/modified files) has NOT yet been synchronized to that branch, so the remote branch is not a buildable VICEBOUND conversion yet.

## Commercial asset gate

The asset ledger contains assets marked evaluation-only / license review pending and an attribution gap for some character base assets. The Android export preset excludes the evaluation-only Hunyuan-derived files by path pattern, but the actual exported package must be inspected to verify exclusion. Do not ship those assets until the rights and attribution are resolved. The code license does not grant rights to third-party assets. See `docs/VICEBOUND_COMMERCIAL_RELEASE_GATE.md` for the full no-go checklist.

## Required release sequence

1. Restore the missing LFS objects and pinned submodule from an authorized upstream checkout; verify hashes.
2. Resolve every evaluation-only asset and attribution gap or replace the affected assets with cleared originals.
3. Install Godot 4.6 and matching Android export templates, plus the Android SDK/JDK versions supported by that exact Godot build.
4. Run `tools/check.sh`, fix all import/lint/test failures, and test the touch controls on at least one low/mid-range Android device.
5. Profile CPU/GPU/RAM/thermal behaviour and reduce world streaming, crowd, shadow, texture and draw-call costs until the device target is met.
6. Integrate maintained AdMob and Play Billing plugins compatible with the pinned Godot version. Add consent/privacy handling and test IDs.
7. Implement server-side purchase-token verification, transaction deduplication, acknowledgement/consumption, refund reconciliation and signed offline entitlement receipts.
8. Create and verify Play Console products, package ID, signing key, privacy policy and store listing.
9. Export a signed AAB, run internal-track tests, then stage a production release.

The current deliverable is an updated local source bundle, not a working APK or a store-ready game. A local workflow trigger was expanded to include `vicebound/android-foundation`; it has not been run.
