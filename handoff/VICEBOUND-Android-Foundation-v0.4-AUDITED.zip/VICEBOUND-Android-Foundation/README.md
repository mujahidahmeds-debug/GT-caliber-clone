# VICEBOUND

**A proposed offline-first, single-player open-world crime game for Android.**

VICEBOUND is a commercial rebrand and mobile adaptation of the supplied Godot project.
It is not affiliated with Rockstar Games or Take-Two Interactive. The game must use
original branding, characters, city content, vehicles, audio and other assets, and must
not include content copied from any commercial game.

## Current conversion status

This archive is an **updated conversion source bundle**, not a finished or tested Android release.

Prepared:
- Godot application display name and main menu rebranded to VICEBOUND.
- Local single-player save architecture retained.
- Provider-neutral monetization boundary added.
- Rewarded-ad and interstitial placement policy scaffolded.
- Google Play product catalogue identifiers added.
- Provisional Android ARM64 export preset added.
- GitHub Actions cloud debug-build workflow added.
- Android touch overlay added; mobile camera-look input gate corrected after static review.
- Android selects the Godot Mobile renderer and defaults to Low graphics (not device-tested).
- Android export excludes test tooling, evaluation-only Hunyuan-derived character assets and unused intro videos.
- Structural validation: 332 checks passed; this is not a Godot parser or runtime test.

Not yet connected or verified:
- AdMob Android plugin.
- Google Play Billing plugin.
- Server-side purchase-token verification.
- Signed offline entitlement cache.
- Android touch-control behaviour on real hardware.
- Android device performance.
- APK/AAB export.

The repository includes a GitHub Actions workflow at
[`.github/workflows/android-build.yml`](.github/workflows/android-build.yml) for a cloud debug APK build.
See [`docs/ANDROID_CLOUD_BUILD.md`](docs/ANDROID_CLOUD_BUILD.md) for the phone-only trigger steps.

Read [`docs/VICEBOUND_ANDROID_MONETIZATION.md`](docs/VICEBOUND_ANDROID_MONETIZATION.md),
[`docs/VICEBOUND_COMMERCIAL_RELEASE_GATE.md`](docs/VICEBOUND_COMMERCIAL_RELEASE_GATE.md)
and [`VICEBOUND_STATUS.md`](VICEBOUND_STATUS.md) before building.

## Offline-first product rules

The core campaign, city simulation, missions, local currency, player progression and local
save must work without internet access. Ads, new purchases and purchase reconciliation are
optional online services. No always-on game server is required for v1.

The monetization bridge intentionally fails closed: if a provider plugin is not installed or
not initialized, it displays no ads and does not accept purchases. It never fabricates a
successful transaction or ad reward.

## Build prerequisites

- Godot 4.6 matching the project version.
- Git LFS with all binary objects downloaded.
- Git submodules initialized, including `engine/godot-cpp` if native modules are built.
- Android export templates matching the installed Godot version.
- Android SDK / JDK versions supported by that Godot release.

The uploaded ZIP contains Git LFS pointer files instead of their payloads for 198 assets
(707,178,848 bytes represented by the pointers; see [`docs/VICEBOUND_LFS_MISSING_ASSETS.md`](docs/VICEBOUND_LFS_MISSING_ASSETS.md)), and does not contain the populated
`godot-cpp` submodule. The current working copy includes the touch overlay and a static-review correction to camera-look input, but it
has not been run in Godot or tested on a device. Restore these from the authorized upstream before expecting a
successful import or export.

## Source checks

From the repository root:

```bash
git lfs install
git lfs pull
git submodule update --init --recursive
```

Then run the repository's documented check:

```bash
tools/check.sh
```

Open `game/project.godot` with Godot 4.6 and verify the project imports before exporting.

## Commercial licensing

- Code: MIT, see [`LICENSE`](LICENSE).
- Project assets: CC BY 4.0 by default, see [`LICENSE-ASSETS`](LICENSE-ASSETS).
- Third-party asset terms and attribution are recorded in [`docs/ASSETS.md`](docs/ASSETS.md)
  and [`CREDITS.md`](CREDITS.md).

The asset ledger contains items marked evaluation-only / license review pending and a
known attribution gap. Do not ship those assets until the issues are resolved. The code
license does not override third-party asset licenses.

## Branding

Working title: **VICEBOUND**
Tagline: **A CITY WITHOUT LIMITS.**

The Android package identifier in the export preset is provisional. Check Google Play
availability and lock the final identifier before the first public release.
