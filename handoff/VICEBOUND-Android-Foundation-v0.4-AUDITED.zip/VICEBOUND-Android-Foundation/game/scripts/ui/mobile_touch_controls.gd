class_name MobileTouchControls
extends Control
## On-screen controls for Android touch devices.
##
## The left thumb controls movement. Dragging the right half of the screen
## rotates the active camera. Action buttons feed the same InputMap actions used
## by keyboard/gamepad, so gameplay code stays platform-neutral.

const MOVE_DEADZONE: float = 0.18
const LOOK_SCALE: float = 1.0

var _touch_roles: Dictionary = {}
var _touch_positions: Dictionary = {}
var _held_actions: Dictionary = {}
var _move_touch: int = -1
var _move_origin: Vector2 = Vector2.ZERO
var _move_vector: Vector2 = Vector2.ZERO
var _button_layout: Array[Dictionary] = []
var _stick_radius: float = 58.0
var _button_radius: float = 30.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = OS.has_feature("mobile") or OS.has_feature("android")
	z_index = 20
	if visible:
		get_viewport().size_changed.connect(_on_viewport_resized)
		_rebuild_layout()
		queue_redraw()


func _exit_tree() -> void:
	_release_all_actions()


func _on_viewport_resized() -> void:
	_rebuild_layout()
	queue_redraw()


func _rebuild_layout() -> void:
	var view_size := get_viewport_rect().size
	_button_radius = clampf(view_size.x * 0.027, 22.0, 34.0)
	_stick_radius = clampf(view_size.x * 0.052, 48.0, 68.0)
	_button_layout = [
		{
			"action": "fire",
			"label": "FIRE",
			"center": Vector2(view_size.x * 0.88, view_size.y * 0.78),
			"radius": _button_radius * 1.18,
		},
		{
			"action": "jump",
			"label": "JUMP",
			"center": Vector2(view_size.x * 0.75, view_size.y * 0.88),
			"radius": _button_radius,
		},
		{
			"action": "aim",
			"label": "AIM",
			"center": Vector2(view_size.x * 0.72, view_size.y * 0.70),
			"radius": _button_radius * 0.92,
		},
		{
			"action": "interact",
			"label": "USE",
			"center": Vector2(view_size.x * 0.92, view_size.y * 0.59),
			"radius": _button_radius * 0.92,
		},
		{
			"action": "sprint",
			"label": "RUN",
			"center": Vector2(view_size.x * 0.34, view_size.y * 0.83),
			"radius": _button_radius * 0.9,
		},
		{
			"action": "reload",
			"label": "R",
			"center": Vector2(view_size.x * 0.84, view_size.y * 0.94),
			"radius": _button_radius * 0.72,
		},
		{
			"action": "melee",
			"label": "HIT",
			"center": Vector2(view_size.x * 0.61, view_size.y * 0.88),
			"radius": _button_radius * 0.88,
		},
		{
			"action": "pause",
			"label": "Ⅱ",
			"center": Vector2(view_size.x * 0.96, view_size.y * 0.09),
			"radius": _button_radius * 0.72,
		},
		{
			"action": "phone",
			"label": "P",
			"center": Vector2(view_size.x * 0.45, view_size.y * 0.09),
			"radius": _button_radius * 0.88,
		},
		{
			"action": "weapon_next",
			"label": "WPN",
			"center": Vector2(view_size.x * 0.57, view_size.y * 0.09),
			"radius": _button_radius * 0.88,
		},
	]


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if get_tree().paused:
		if event is InputEventScreenTouch and not (event as InputEventScreenTouch).pressed:
			_release_touch(event as InputEventScreenTouch)
		return
	if event is InputEventScreenTouch:
		_handle_touch(event as InputEventScreenTouch)
	elif event is InputEventScreenDrag:
		_handle_drag(event as InputEventScreenDrag)


func _handle_touch(event: InputEventScreenTouch) -> void:
	var touch_id := event.index
	if event.pressed:
		var button := _button_at(event.position)
		if not button.is_empty():
			var action: String = button.action
			_touch_roles[touch_id] = {"kind": "button", "action": action}
			_touch_positions[touch_id] = event.position
			if action == "pause":
				_set_action(action, true)
				_set_action(action, false)
			else:
				_set_action(action, true)
			queue_redraw()
			get_viewport().set_input_as_handled()
			return

		var view_size := get_viewport_rect().size
		if (
			event.position.x <= view_size.x * 0.43
			and event.position.y >= view_size.y * 0.48
			and _move_touch < 0
		):
			_move_touch = touch_id
			_move_origin = event.position
			_move_vector = Vector2.ZERO
			_touch_roles[touch_id] = {"kind": "move"}
			_touch_positions[touch_id] = event.position
			queue_redraw()
			get_viewport().set_input_as_handled()
		elif event.position.x > view_size.x * 0.43:
			_touch_roles[touch_id] = {"kind": "look"}
			_touch_positions[touch_id] = event.position
			get_viewport().set_input_as_handled()
		return

	_release_touch(event)


func _release_touch(event: InputEventScreenTouch) -> void:
	var touch_id := event.index
	if not _touch_roles.has(touch_id):
		return
	var role: Dictionary = _touch_roles[touch_id]
	if role.kind == "button":
		var action: String = role.action
		_set_action(action, false)
	elif role.kind == "move":
		_move_touch = -1
		_move_vector = Vector2.ZERO
		_update_move_actions()
	_touch_roles.erase(touch_id)
	_touch_positions.erase(touch_id)
	queue_redraw()
	get_viewport().set_input_as_handled()


func _handle_drag(event: InputEventScreenDrag) -> void:
	if not _touch_roles.has(event.index):
		return
	var role: Dictionary = _touch_roles[event.index]
	_touch_positions[event.index] = event.position
	if role.kind == "move":
		var offset := event.position - _move_origin
		_move_vector = (offset / _stick_radius).limit_length(1.0)
		_update_move_actions()
	elif role.kind == "look":
		var mouse_motion := InputEventMouseMotion.new()
		mouse_motion.position = event.position
		mouse_motion.global_position = event.position
		mouse_motion.relative = event.relative * LOOK_SCALE
		Input.parse_input_event(mouse_motion)
	queue_redraw()
	get_viewport().set_input_as_handled()


func _update_move_actions() -> void:
	_set_action("move_left", _move_vector.x < -MOVE_DEADZONE, absf(_move_vector.x))
	_set_action("move_right", _move_vector.x > MOVE_DEADZONE, absf(_move_vector.x))
	_set_action("move_forward", _move_vector.y < -MOVE_DEADZONE, absf(_move_vector.y))
	_set_action("move_back", _move_vector.y > MOVE_DEADZONE, absf(_move_vector.y))


func _set_action(action: String, pressed: bool, strength: float = 1.0) -> void:
	var was_pressed := bool(_held_actions.get(action, false))
	if pressed and not was_pressed:
		_emit_action_event(action, true, strength)
	elif pressed:
		Input.action_press(action, clampf(strength, 0.0, 1.0))
	elif was_pressed:
		_emit_action_event(action, false, 0.0)
	_held_actions[action] = pressed


func _emit_action_event(action: String, pressed: bool, strength: float) -> void:
	var action_event := InputEventAction.new()
	action_event.action = action
	action_event.pressed = pressed
	action_event.strength = clampf(strength, 0.0, 1.0)
	Input.parse_input_event(action_event)


func _button_at(point: Vector2) -> Dictionary:
	for index in range(_button_layout.size() - 1, -1, -1):
		var button: Dictionary = _button_layout[index]
		if point.distance_to(button.center) <= float(button.radius):
			return button
	return {}


func _release_all_actions() -> void:
	for action_variant in _held_actions.keys():
		var action := str(action_variant)
		if bool(_held_actions[action]):
			_emit_action_event(action, false, 0.0)
	_held_actions.clear()
	_touch_roles.clear()
	_touch_positions.clear()
	_move_touch = -1
	_move_vector = Vector2.ZERO


func _draw() -> void:
	if not visible:
		return
	var base := Color(0.04, 0.06, 0.08, 0.34)
	var rim := Color(0.9, 0.94, 1.0, 0.48)
	var knob := Color(0.78, 0.86, 0.94, 0.44)
	var view_size := get_viewport_rect().size
	var stick_center := (
		_move_origin
		if _move_touch >= 0
		else Vector2(view_size.x * 0.17, view_size.y * 0.79)
	)
	draw_circle(stick_center, _stick_radius, base)
	draw_arc(stick_center, _stick_radius, 0.0, TAU, 48, rim, 2.0, true)
	var knob_center := stick_center + _move_vector * _stick_radius * 0.72
	draw_circle(knob_center, _stick_radius * 0.42, knob)
	for button in _button_layout:
		var center: Vector2 = button.center
		var radius: float = button.radius
		var pressed := false
		for role in _touch_roles.values():
			if role.kind == "button" and role.action == button.action:
				pressed = true
				break
		var fill := Color(0.08, 0.1, 0.13, 0.62 if pressed else 0.34)
		draw_circle(center, radius, fill)
		draw_arc(center, radius, 0.0, TAU, 40, Color(1, 1, 1, 0.62), 2.0, true)
		var font := ThemeDB.fallback_font
		var font_size := 14 if radius > 25.0 else 12
		var label := str(button.label)
		var text_size := font.get_string_size(label, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
		draw_string(
			font,
			center + Vector2(-text_size.x * 0.5, text_size.y * 0.35),
			label,
			HORIZONTAL_ALIGNMENT_LEFT,
			-1,
			font_size,
			Color(1, 1, 1, 0.9)
		)
