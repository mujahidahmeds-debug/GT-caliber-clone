class_name MonetizationCatalog
extends RefCounted
## Store product identifiers and reward values in one place.
## Prices are configured in Google Play Console and must be localized by Billing.

const REWARDED_CASH_AMOUNT: int = 500
const INTERSTITIAL_COOLDOWN_SECONDS: float = 300.0
const MAX_INTERSTITIALS_PER_SESSION: int = 6

const PRODUCTS: Dictionary = {
	"vicebound_remove_ads": {
		"kind": "non_consumable",
		"display_name": "Remove Ads",
	},
	"vicebound_cash_small": {
		"kind": "consumable",
		"display_name": "Cash Pack S",
		"soft_currency": 500,
	},
	"vicebound_cash_medium": {
		"kind": "consumable",
		"display_name": "Cash Pack M",
		"soft_currency": 1800,
	},
	"vicebound_cash_large": {
		"kind": "consumable",
		"display_name": "Cash Pack L",
		"soft_currency": 4500,
	},
	"vicebound_vehicle_pack": {
		"kind": "non_consumable",
		"display_name": "Premium Vehicle Pack",
	},
	"vicebound_mission_pack": {
		"kind": "non_consumable",
		"display_name": "Premium Mission Pack",
	},
}


static func has_product(product_id: String) -> bool:
	return PRODUCTS.has(product_id)


static func product(product_id: String) -> Dictionary:
	return PRODUCTS.get(product_id, {}).duplicate(true)
