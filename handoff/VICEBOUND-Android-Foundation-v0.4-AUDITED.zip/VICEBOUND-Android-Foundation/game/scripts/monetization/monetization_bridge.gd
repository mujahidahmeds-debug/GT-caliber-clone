extends Node
## Offline-first monetization boundary for VICEBOUND.
##
## This node deliberately contains NO ad SDK or billing SDK dependency.
## The game remains fully playable when adapters are absent or the device is
## offline. A provider plugin can connect to the request signals and report
## completion through the documented adapter methods below.
##
## SECURITY: set_verified_entitlement() is a trust boundary. Only call it after
## Google Play purchase verification has succeeded. Production integration
## should validate purchase tokens server-side and cache a signed entitlement
## receipt that can be checked offline. Never trust a raw client purchase event.

signal rewarded_ad_requested(request_id: int, placement_id: String)
signal interstitial_ad_requested(placement_id: String)
signal purchase_requested(product_id: String)
signal reward_granted(reward_id: String, amount: int)
signal entitlement_changed(product_id: String, is_owned: bool)

const REWARDED_CASH_ID: String = "mission_cash_bonus"
const INTERSTITIAL_PLACEMENT_MISSION_BREAK: String = "mission_break"

var _ads_adapter_ready: bool = false
var _billing_adapter_ready: bool = false
var _pending_reward_request_id: int = -1
var _next_reward_request_id: int = 1
var _last_interstitial_msec: int = -1
var _interstitials_this_session: int = 0
var _owned_products: Dictionary = {}


func set_ads_adapter_ready(is_ready: bool) -> void:
	_ads_adapter_ready = is_ready


func set_billing_adapter_ready(is_ready: bool) -> void:
	_billing_adapter_ready = is_ready


## Returns a request ID, or -1 if ads are unavailable, disabled, or another
## rewarded ad is already pending. The adapter must emit completion only after
## the ad provider reports a completed reward callback.
func request_rewarded_cash() -> int:
	if not _ads_adapter_ready or _pending_reward_request_id >= 0:
		return -1
	_pending_reward_request_id = _next_reward_request_id
	_next_reward_request_id += 1
	rewarded_ad_requested.emit(_pending_reward_request_id, REWARDED_CASH_ID)
	return _pending_reward_request_id


## Adapter callback: call only after the ad SDK confirms completed reward.
func complete_rewarded_cash(request_id: int) -> bool:
	if request_id < 0 or request_id != _pending_reward_request_id:
		return false
	_pending_reward_request_id = -1
	var players := get_tree().get_nodes_in_group("player_stats")
	if players.is_empty():
		return false
	var player_stats: Node = players[0]
	if not player_stats.has_method("add_money"):
		return false
	player_stats.add_money(MonetizationCatalog.REWARDED_CASH_AMOUNT)
	get_tree().call_group("save_manager", "save_game")
	reward_granted.emit(REWARDED_CASH_ID, MonetizationCatalog.REWARDED_CASH_AMOUNT)
	return true


func cancel_rewarded_cash(request_id: int) -> void:
	if request_id == _pending_reward_request_id:
		_pending_reward_request_id = -1


## Interstitials are restricted to natural breaks, never active gameplay.
## Cooldown is recorded only after the adapter confirms that an ad was shown.
func request_interstitial(placement_id: String) -> bool:
	if not _ads_adapter_ready or is_remove_ads_owned():
		return false
	if _interstitials_this_session >= MonetizationCatalog.MAX_INTERSTITIALS_PER_SESSION:
		return false
	var now := Time.get_ticks_msec()
	var cooldown_msec := int(MonetizationCatalog.INTERSTITIAL_COOLDOWN_SECONDS * 1000.0)
	if _last_interstitial_msec >= 0 and now - _last_interstitial_msec < cooldown_msec:
		return false
	if placement_id != INTERSTITIAL_PLACEMENT_MISSION_BREAK:
		return false
	interstitial_ad_requested.emit(placement_id)
	return true


## Adapter callback after the provider actually displayed the interstitial.
func mark_interstitial_shown() -> void:
	_last_interstitial_msec = Time.get_ticks_msec()
	_interstitials_this_session += 1


func request_purchase(product_id: String) -> bool:
	if not _billing_adapter_ready or not MonetizationCatalog.has_product(product_id):
		return false
	var product_data := MonetizationCatalog.product(product_id)
	if has_entitlement(product_id) and product_data.get("kind") == "non_consumable":
		return false
	purchase_requested.emit(product_id)
	return true


## Trust boundary for the billing adapter. `verified` must mean the purchase
## token was validated, not merely that the client SDK emitted PURCHASED.
## Consumable delivery must be idempotent and transaction-ID deduplicated by
## the production billing adapter before calling this method.
func set_verified_entitlement(product_id: String, is_owned: bool) -> bool:
	if not MonetizationCatalog.has_product(product_id):
		return false
	_owned_products[product_id] = is_owned
	entitlement_changed.emit(product_id, is_owned)
	return true


func has_entitlement(product_id: String) -> bool:
	return bool(_owned_products.get(product_id, false))


func is_remove_ads_owned() -> bool:
	return has_entitlement("vicebound_remove_ads")


func ads_available() -> bool:
	return _ads_adapter_ready


func billing_available() -> bool:
	return _billing_adapter_ready


func reset_session_ad_limits() -> void:
	_interstitials_this_session = 0
	_last_interstitial_msec = -1
	_pending_reward_request_id = -1
