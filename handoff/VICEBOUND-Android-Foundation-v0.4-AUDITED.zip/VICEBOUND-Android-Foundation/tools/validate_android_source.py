#!/usr/bin/env python3
"""Offline structural checks for the VICEBOUND Godot Android source bundle."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT / "game"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument(
    "--require-lfs",
    action="store_true",
    help="fail if any Git LFS pointer remains (use after checkout with LFS enabled)",
)
ARGS = parser.parse_args()
errors: list[str] = []
checks: list[str] = []


def check(condition: bool, message: str) -> None:
    if condition:
        checks.append(message)
    else:
        errors.append(message)


project = (GAME / "project.godot").read_text(encoding="utf-8")
check('config/name="VICEBOUND"' in project, "Godot project display name is VICEBOUND")
check('config/version="0.1.0"' in project, "development version is set")
world_scene = (GAME / "scenes/world/miami.tscn").read_text(encoding="utf-8")
check('title = "WELCOME TO SUNCOAST CITY"' in world_scene, "gameplay city title uses original Suncoast City branding")
check("VICE CITY" not in world_scene.upper(), "main world scene has no Vice City franchise naming")
main_scene = re.search(r'run/main_scene="([^"]+)"', project)
check(bool(main_scene), "main scene is configured")
if main_scene:
    main_path = GAME / main_scene.group(1).removeprefix("res://")
    check(main_path.is_file(), f"main scene exists: {main_scene.group(1)}")

# Every script/scene/texture resource path explicitly referenced by a scene must exist.
scene_refs = 0
for scene in GAME.rglob("*.tscn"):
    content = scene.read_text(encoding="utf-8", errors="replace")
    for resource_path in re.findall(r'path="res://([^"]+)"', content):
        scene_refs += 1
        check((GAME / resource_path).exists(), f"scene resource exists: {scene.relative_to(GAME)} -> {resource_path}")
check(scene_refs > 0, "scene resource references were inspected")

# Verify touch-control actions are present in the project's InputMap.
input_block = project.split("[input]", 1)[1].split("\n[", 1)[0] if "[input]" in project else ""
actions = set(re.findall(r"^([a-zA-Z0-9_]+)=\{", input_block, re.MULTILINE))
touch_script = (GAME / "scripts/ui/mobile_touch_controls.gd").read_text(encoding="utf-8")
required = {
    "move_left", "move_right", "move_forward", "move_back", "fire", "aim",
    "jump", "sprint", "interact", "reload", "melee", "phone", "weapon_next", "pause",
}
missing = sorted(required - actions)
check(not missing, "all touch actions exist in InputMap" + (f": missing {missing}" if missing else ""))
check('MobileTouchControls' in (GAME / "scenes/ui/game_hud.tscn").read_text(encoding="utf-8"), "mobile touch overlay is attached to the in-game HUD")
check("OS.has_feature(\"mobile\")" in touch_script and "OS.has_feature(\"android\")" in touch_script, "touch overlay is platform-gated")
check("InputEventAction.new()" in touch_script and "Input.parse_input_event(action_event)" in touch_script, "touch buttons dispatch InputMap events for event-driven gameplay systems")
for camera_file in ("orbit_camera.gd", "chase_camera.gd"):
    camera_script = (GAME / "scripts/camera" / camera_file).read_text(encoding="utf-8")
    check(
        'OS.has_feature("mobile")' in camera_script
        and "Input.MOUSE_MODE_CAPTURED" in camera_script,
        f"{camera_file} accepts touch-generated camera motion without changing desktop mouse capture",
    )
rendering_block = project.split("[rendering]", 1)[1].split("\n[", 1)[0] if "[rendering]" in project else ""
check('renderer/rendering_method.mobile="mobile"' in rendering_block, "Android uses the Godot Mobile renderer override in the rendering section")
quality_script = (GAME / "scripts/world/graphics_quality.gd").read_text(encoding="utf-8")
settings_script = (GAME / "scripts/ui/settings_panel.gd").read_text(encoding="utf-8")
check(
    "Viewport.SCALING_3D_MODE_BILINEAR" in quality_script
    and "mobile_default := Tier.LOW" in quality_script
    and "GraphicsQuality.Tier.LOW" in settings_script,
    "mobile defaults to low-cost graphics scaling",
)

preset = (GAME / "export_presets.cfg").read_text(encoding="utf-8")
check('name="Android"' in preset, "Android export preset exists")
check('package/unique_name="com.aizudi.vicebound"' in preset, "provisional Android package ID is set")
check('architectures/arm64-v8a=true' in preset, "Android ARM64 export is enabled")
check('package/signed=true' in preset, "debug APK signing is enabled")
check(
    'exclude_filter="tests/**,addons/gdUnit4/**,assets/characters/char_hunyuan*,assets/characters/char_textured*,assets/ui/video/*"' in preset,
    "Android export excludes test tooling, evaluation-only Hunyuan-derived assets and unused intro videos",
)

lfs_count = 0
for file in GAME.rglob("*"):
    if file.is_file() and file.stat().st_size < 200:
        try:
            if file.read_bytes().startswith(b"version https://git-lfs.github.com/spec/v1"):
                lfs_count += 1
        except OSError:
            pass
if ARGS.require_lfs:
    check(lfs_count == 0, f"all Git LFS objects are materialized (remaining pointers: {lfs_count})")
else:
    check(lfs_count == 198, f"uploaded source LFS pointer count recorded (found {lfs_count})")

for item in checks:
    print(f"PASS  {item}")
for item in errors:
    print(f"FAIL  {item}")
print(f"\n{len(checks)} passed, {len(errors)} failed")
print(f"Git LFS pointer files: {lfs_count}")
print("NOTE  This is a structural check only; it does not parse GDScript or build/run Godot.")
if not ARGS.require_lfs:
    print("NOTE  Run with --require-lfs in CI after Git LFS checkout to require all binary payloads.")
sys.exit(1 if errors else 0)
