# VICEBOUND Completion Audit

Audit date: 2026-11-24
Working package: VICEBOUND Android Foundation v0.3

## Verified in this environment

- ZIP archive extracted and inspected successfully.
- Existing structural validator: **336 passed, 0 failed**.
- Validator scope is structural only. It does not parse GDScript, import Godot resources, execute gameplay, or build an APK.
- GitHub connector write test previously succeeded: branch `vicebound/android-foundation` and `VICEBOUND_REMOTE_HANDOFF.md` commit created. The complete local source bundle has not been synchronized to that branch.

## Blocking asset and dependency facts

- Git LFS pointer files found in `game/`: **198**.
- Missing binary payload size declared by pointers: **707,178,848 bytes (674.42 MiB)**.
- Git submodule declaration: `engine/godot-cpp` -> `https://github.com/godotengine/godot-cpp`.
- This environment has no Godot executable, Android SDK, adb, or Godot export templates. Java is present.
- Network access from the build container is unavailable, so LFS objects, submodules, Godot, export templates, and SDK packages could not be fetched.

## Release integrations not implemented

- AdMob Android plugin and consent/privacy integration.
- Google Play Billing integration and Play Console product setup.
- Server-side purchase-token verification, transaction idempotency, refund/revocation reconciliation, and signed offline entitlement receipts.
- Production signing key, final package ID confirmation, privacy policy, store listing, and Play Console internal testing.

## Commercial asset gate

The existing asset ledger marks Hunyuan-derived character assets as evaluation-only/license review pending. `CREDITS.md` also identifies a missing attribution entry for the Tripo coastal-resident base characters. The export exclusion patterns are not proof that the final APK excludes every restricted asset. A release build must be inspected and the ledger/credits reconciled before distribution.

## Current result

**Not release-ready. No APK or AAB has been built or device-tested.**

The project cannot be honestly marked complete until the missing binary assets and submodule are restored, the full source conversion is synchronized, Godot import/parser/tests pass, an Android artifact is built, physical-device testing passes, and commercial rights plus monetization integrations are cleared.

## LFS pointer inventory

| Path | SHA-256 | Declared bytes |
|---|---|---:|
| `game/addons/gdUnit4/src/core/assets/touch-button.png` | `e709c40067fec99c3b59c78a5a364da8c326a94c49a56337a46c98976d3db4cb` | 3,292 |
| `game/addons/gdUnit4/src/update/assets/dot2.png` | `c12758bd1b0b0ef88811b50affd3957bbf9c9e6c0922c0de199a4a3649643103` | 883 |
| `game/addons/gdUnit4/src/update/assets/dot1.png` | `f37474a8d5dc0c9574cef6fad5308922841e60deb31213e2723e3dd2755bd7e5` | 730 |
| `game/addons/gdUnit4/src/update/assets/border_top.png` | `ca6f5d7f59cf272dc87fc4762bd7ec82502bb1987c7803ebaea594408401ac47` | 1,749 |
| `game/addons/gdUnit4/src/update/assets/embedded.png` | `08cead78bbc3d7aefda91f376b1280195333d94a32222b1490876fabf0823f6b` | 287 |
| `game/addons/gdUnit4/src/update/assets/border_bottom.png` | `37a40709349e82f04b542de8d17c4118d68531f6515964b0e03f28f6ee529772` | 1,757 |
| `game/addons/gdUnit4/src/update/assets/horizontal-line2.png` | `fb01fb89e6b3ff826f05e772336f0cd855e1e838ef920cac9fd6a3e3504dacd9` | 332 |
| `game/addons/gdUnit4/src/ui/settings/logo.png` | `ed176306a061dff6c2a97c76e572bbbdee50cb7f5a496ba10d6898721f198351` | 49,775 |
| `game/addons/gdUnit4/src/reporters/html/template/css/logo.png` | `ed176306a061dff6c2a97c76e572bbbdee50cb7f5a496ba10d6898721f198351` | 49,775 |
| `game/assets/textures/stucco_albedo.png` | `34e8a99f6d5dc407348f94aa465ebdc202396a4e92eea2a152fec15efe33dc5b` | 1,704,645 |
| `game/assets/textures/sand_albedo.png` | `7032c1caf9ef8906e1744b41da87027c6d737e8c99d72cd6fc82192b821fdb49` | 2,297,056 |
| `game/assets/textures/cotton.png` | `e6f6bf9178af0562344bb04eb3dd97570479477a4bc5d49279303e4bfcc34f0b` | 2,029,670 |
| `game/assets/textures/skin_albedo.png` | `504b3348992e8ddbe8155f73911976081480d5864ae2d60c8d713c6bbe014947` | 1,645,762 |
| `game/assets/textures/asphalt_albedo.png` | `a2485f5a4f444bced466e9733868f62c5139079bccc171efd0108f999507b6d6` | 2,238,305 |
| `game/assets/textures/sidewalk_albedo.png` | `59c155f6d96ae3df27baae04729856fd6991fa710872b45303038d25e8b71453` | 2,053,188 |
| `game/assets/textures/leather.png` | `c9460e11b4d7c1f98bb9a38ba30a32b9ce5b13b3a23faceeea4a9f9898110f2e` | 1,924,196 |
| `game/assets/textures/denim.png` | `4ae28c983e2edfef509e1806d47045397b56b90bdd48d0e21ca5a104270b17a4` | 2,609,738 |
| `game/assets/map/florida_full_map.png` | `da07efc943da07a1727e904ed26ce7af37ea43c06e2d3a9a64ea3fb06d160dee` | 87,686 |
| `game/assets/characters/char_textured_front.glb` | `bc0c878e7de118da954eb1c598be71b489c0eee87ee022ce342b85d1dc896335` | 10,060,616 |
| `game/assets/characters/char_textured.glb` | `7b5bf492ad02037d28090c6ff61daef05a74115f27a24873f622e31b92af16a8` | 15,893,508 |
| `game/assets/characters/char_textured_char_ref_clean.png` | `ad92465047aa7060804c8a78e0fd9fe96abec6f63b2e5a61166ba2cffc4c1177` | 1,251,464 |
| `game/assets/characters/mara_three_proxy.glb` | `c3c4537f9b414382ac48c0a0cfdb941df3c67971bb77e978485092ae1814d7e9` | 736,996 |
| `game/assets/characters/char_textured_front_char_ref_clean.png` | `ad92465047aa7060804c8a78e0fd9fe96abec6f63b2e5a61166ba2cffc4c1177` | 1,251,464 |
| `game/assets/characters/char_hunyuan.glb` | `468f16a7ad96ac879c59f7327a87fd99b55f9932cacfa129091acdd489314eb3` | 3,355,572 |
| `game/assets/characters/mara_three_rigged_proxy.glb` | `bb9e30202fd4b495bad86731a9af5f3ebfde1d560fd8b39cb8fbc4e6d877e64c` | 1,997,624 |
| `game/assets/characters/char_textured_char_ref.png` | `4333958964d91a798f1d64ea144daa83df7e1166dad5cdd581abbce1241ba606` | 1,316,669 |
| `game/assets/buildings/poc_bayfront_tower_roughness.png` | `9b5a6d68fe17a9e4aaed273af2f789a600dab424ea0b674ede4d5b4e3239f602` | 849,985 |
| `game/assets/buildings/florida_neon_detail_pack.glb` | `99a7d35dde54dcc1ac86159a4f22d5059e1f417a4f05f1fc11f1dbdd3869484e` | 263,472 |
| `game/assets/buildings/florida_city_block_pack.glb` | `0563ea37cf2b5eab4701c35c2880d39e94160f4452ecce4ca605fe91c074b848` | 583,024 |
| `game/assets/buildings/poc_bayfront_tower_normal_3.png` | `c6f188657a54d4b73924d9f39b57986819dbdcc7350bdf1e5b423994a6be5515` | 5,623,070 |
| `game/assets/buildings/poc_bayfront_tower_albedo.png` | `dd2415530074db5f44cebb7387011ad34f0723e375b35e894db06f97ab76b7b4` | 1,446,006 |
| `game/assets/buildings/poc_bayfront_tower_roughness_5.png` | `2292497d9816fe1ad59ae36bcda7b6d7c74eb96a786780f0ddf9fb9d4e5ba42f` | 1,166,897 |
| `game/assets/buildings/poc_bayfront_tower_albedo_4.png` | `a6b727bfe5b5d9a020e71ec7a07afb373a8bd095a604359ac4d3e78c905e968f` | 1,755,919 |
| `game/assets/buildings/florida_regional_pack.glb` | `7f4764d2a789950091300db3dd3ddd1fe1a7bd9532cc4f647c9064f814d66262` | 639,800 |
| `game/assets/buildings/poc_bayfront_tower.glb` | `2d52c4489c60395ec86965c5cda9b67d1fa3a95d838f96717f08a4add8efa664` | 37,825,164 |
| `game/assets/buildings/florida_environment_pack.glb` | `160688079a202bd17caf244b6a654545556fe4a4f8da5035ae3718893a1c34e6` | 1,170,872 |
| `game/assets/buildings/florida_streetlife_pack.glb` | `ad25ee3dace3b4f45cf84b442953a2027f2a5c83a0339dc9179491dfa9dc8ecb` | 1,511,884 |
| `game/assets/buildings/florida_infrastructure_pack.glb` | `874c4aa27b63745559f444aafea301ca9a437609d6524d32e194f067c6e8c177` | 508,760 |
| `game/assets/buildings/florida_vista_pack.glb` | `9232af8574b9d121286b619ef2eb39493f7d5c041371389a34b4cea07821a176` | 1,827,048 |
| `game/assets/buildings/florida_traffic_marine_pack.glb` | `7701985fbf4cd976e1dac33018a40c3761449cf9104aa248d819fb95b45cdf3d` | 584,220 |
| `game/assets/buildings/florida_landmark_pack.glb` | `2ab92df4da22c10081367c9d4cb76c39044298ac941c2ac93fa11f274ecb6775` | 348,964 |
| `game/assets/buildings/poc_bayfront_tower_normal.png` | `1af54b3f4743b745387c1e948069c46b5ae1ce8ff39c406d74b7bf5887fe953e` | 5,947,312 |
| `game/assets/environment/coastal_props/palm_planter_tripo_model_normal.jpg` | `baf97aa9b52af6bb6ee285d4e83698818ba2f9fee3357bd399d7ca31ccaf9b6a` | 355,716 |
| `game/assets/environment/coastal_props/street_lamp.glb` | `6a0deabc9234d9c065f77fd1b01ddecfdaffa4f516d37e3f0bb6f1e557d89845` | 300,136 |
| `game/assets/environment/coastal_props/palm_tree_tripo_model_basecolor.jpg` | `f03a0448021e67c01f85fad76a3924fac4c5ed13b9d1cb5fa785d9001552831c` | 840,259 |
| `game/assets/environment/coastal_props/street_lamp_tripo_model_rm.jpg` | `3235a4bf5aff59a9233bc3d2d4eddd74331faa1c12351776e659ccc91aa1d474` | 89,457 |
| `game/assets/environment/coastal_props/palm_planter_tripo_model_rm.jpg` | `da4bb80ae0fd4bb2f18ef020c3cd61d680a6ab44e9329af57afb7b70489b6a5b` | 551,417 |
| `game/assets/environment/coastal_props/palm_tree.glb` | `0d08902b530276aff79b49fd1074fd092fff86fdf58cf7f23b6004f0c71dce60` | 1,887,352 |
| `game/assets/environment/coastal_props/street_lamp_tripo_model_normal.jpg` | `dbde0d650de4250b1400eb566e59211a39c7b06ba76439bc7b566902457bc8e7` | 28,683 |
| `game/assets/environment/coastal_props/palm_tree_tripo_model_normal.jpg` | `f9c3d7970b255a840a4181164395c5b18eb6ec20c9ae27273b82c35f9c4fcc95` | 318,840 |
| `game/assets/environment/coastal_props/palm_tree_tripo_model_rm.jpg` | `b340fc2bfc0f08680b0bf0c3a445a4fc735d122b349587565c167bcdb42b50bb` | 555,480 |
| `game/assets/environment/coastal_props/street_lamp_tripo_model_basecolor.jpg` | `4382cf4ffcb02cad06c2ca6248315e42eab802dc638769e0b03d59d82099ef66` | 95,563 |
| `game/assets/environment/coastal_props/palm_planter_tripo_model_basecolor.jpg` | `0f9749de9bc193652ed8c38b33997725496b819982374508351408244101db53` | 1,006,612 |
| `game/assets/environment/coastal_props/palm_planter.glb` | `4c920676d2a9da5e81b60f674e5f3bc31615cd8b47cfe2f10141d64770ed31a2` | 2,167,272 |
| `game/assets/buildings/library/biz_04.glb` | `eae9f189d1afa5d551d4b3397bb4b1d791359066438beb260acca07e3fa56a3c` | 1,204,704 |
| `game/assets/buildings/library/house_02.glb` | `82ddca19bb5bb1bf0c7f69f9a6f843a6a336fc7ef4022f9066c75e2be1c5c0fa` | 6,148 |
| `game/assets/buildings/library/tower_01.glb` | `2103713ef368c04f61444d03c3225dc56a3a6e678c4e9e56850adafa6cc9d845` | 7,767,836 |
| `game/assets/buildings/library/mid_03.glb` | `dde99bd4accaf566a54292ef0b41cb134e0eb883cac4c9d4a89b5e4c13cb4870` | 3,191,736 |
| `game/assets/buildings/library/house_01.glb` | `8266d5a9f81438a1be58e0e69a1dbf96d6663030ea2c8f6da456273eec9c3b21` | 7,272 |
| `game/assets/buildings/library/tower_04.glb` | `3fec3f004248254b3e3f62126e159b880b3a5ea2f3917983a3ce9cf19f0c30ac` | 7,825,320 |
| `game/assets/buildings/library/mid_05.glb` | `786063b87750a32dc8ecc349a009748de74da8635187477a75da69b2e5e26d26` | 3,695,712 |
| `game/assets/buildings/library/tower_02.glb` | `362e5b97759aa4f06d154277984f7f166c8752a8201c5e2c30e28f3b773c1074` | 8,299,960 |
| `game/assets/buildings/library/tower_05.glb` | `49cc4ff974d99dca0b5635c845436f73ab9d65924c08615b117e07422f40c64b` | 8,297,256 |
| `game/assets/buildings/library/biz_01.glb` | `d4f8158d86e8a0893b5fb499b448ea354f3231991bd2b7f2cf38e830947229cb` | 1,310,424 |
| `game/assets/buildings/library/biz_02.glb` | `396dc802fd11748d42b7c3483cda24aa0f467802953dca2ee3a0b370f267b95f` | 1,253,600 |
| `game/assets/buildings/library/house_03.glb` | `7967db09f923c1970c3f5f93549bee488aac195b8d382a1675c845e9c3b87df6` | 7,896 |
| `game/assets/buildings/library/tower_03.glb` | `e79a99e9a907111d00d35a74ac6e5056d6ca4b628bd6c54334a8eedfc0610fd6` | 8,076,784 |
| `game/assets/buildings/library/mid_02.glb` | `48ba0e5a1c5a9c9d05af4e807ef103765aac35e0b35ffa3451ca22712debccbf` | 3,510,916 |
| `game/assets/buildings/library/biz_03.glb` | `e6680e1e076c8a41470436a457dd884a857f783899117c406f4fac3190861f6a` | 1,262,236 |
| `game/assets/buildings/library/house_04.glb` | `61aa63ccbe517e4fefe5ef9e7cedf61b39464619bc75b08dbe16c2a9d6c345af` | 7,260 |
| `game/assets/buildings/library/mid_04.glb` | `c4c9a0a9f8397268cd1cb0a603183ffd4d37cea1255cf1db4d2475511362f215` | 4,075,192 |
| `game/assets/buildings/library/mid_01.glb` | `7056120bf568e8da051d6c93e2aac23295e730394a5b5f28663651bcfd3b83d6` | 3,187,400 |
| `game/assets/characters/mc/mc_shirtless_full_anims_texture_0.png` | `79ef7dc76832d54b126e608305c058469589f79e230d1919ecfa11ee45228590` | 18,938,129 |
| `game/assets/characters/mc/mc_dressed_full_anims.glb` | `aa1e63da108267b671feb466b1dff93c9f7bc0398b66b8c298f116e03c870838` | 25,684,756 |
| `game/assets/characters/mc/mc_dressed_full_anims_texture_0.png` | `b3d0345e0827048d9274e20d43595014f96d8fe45869db33bfe74eb5bc69b02e` | 21,650,793 |
| `game/assets/characters/mc/T_Superhero_Male_Roughness.png` | `c70dabf48574cda55644d556beae1ee7cf1bdcf68a50d259d20f2f2358f27991` | 3,152,049 |
| `game/assets/characters/mc/Superhero_Male_FullBody.gltf` | `e2a68c400eedbaed172fc0f2de8e665df66ceccab27fcbcf2152682322405ce4` | 30,981 |
| `game/assets/characters/mc/T_Eye_Brown.png` | `d08e3356a83211bc6ca21fe3a8e39f4b5c1a3b8f85457fc2c0fb57be09935025` | 35,958 |
| `game/assets/characters/mc/T_Hair_1_BaseColor.png` | `bc7aa863bd22ab0a995cd838cceb4d3a5186ee54ee2fb0108fad85d20c057e6e` | 1,570,376 |
| `game/assets/characters/mc/T_Hair_1_Normal.png` | `57fd0ad8c96a4d01b38769637e066cecaa285b456f6e48ce00863754a457affb` | 4,326,126 |
| `game/assets/characters/mc/Hair_SimpleParted.gltf` | `fe0f354d7f95d83d38e15c60794dcc063fa4d60550706f3d7ba51491cdc07c56` | 23,114 |
| `game/assets/characters/mc/T_Superhero_Male_Dark.png` | `df680cbc1967a61e85998bfafb8f7bc0a36dd604bb3266486c4b06b1a184bb45` | 1,384,380 |
| `game/assets/characters/mc/mc_shirtless_full_anims.glb` | `6f98af2dcf6bf2598cd94108b0a982051d8ec61ea0f47992993bcbb5e0e6f4ea` | 22,497,160 |
| `game/assets/characters/mc/Superhero_Male_FullBody.bin` | `459003f9745853ae562a85506a2b94dd56515c1f37728f9fa3d2ce1a3e4cd92f` | 720,076 |
| `game/assets/characters/mc/Hair_SimpleParted.bin` | `ecd7c81959f3985d6254458a440daaaa18a8bfbb1dbe111c68a04a72374d54db` | 51,332 |
| `game/assets/characters/mc/T_Superhero_Male_Normal.png` | `9b25cf9200216eb754b79cf4c63b5380c419780788322f3c57cdd2b3e02679a6` | 4,252,937 |
| `game/assets/characters/mc/T_Eye_Normal.png` | `9ed61f7726a54fe346a78b9e5a18905d8e2b88f86235d97f53cd207a26f3f8c7` | 15,099 |
| `game/assets/characters/universal_animations/UAL1_Standard.glb` | `d867292451e432b735e2a910c2db6640fbea97b205d85a2e8ffed26da87972cf` | 8,114,364 |
| `game/assets/characters/npc_female_01/T_Superhero_Female_Dark_BaseColor.png` | `d366843ee7d9e9f37ec87a0e1c98c7f2e45573c08eeb80a51a6d9344e68cf288` | 1,319,410 |
| `game/assets/characters/npc_female_01/T_Eye_Brown.png` | `d08e3356a83211bc6ca21fe3a8e39f4b5c1a3b8f85457fc2c0fb57be09935025` | 35,958 |
| `game/assets/characters/npc_female_01/T_Hair_2_BaseColor.png` | `f9f4f2fb3eeeefb0b6f0fdef38b0770fd6607640c1c680b8139dd76697e9f9b3` | 1,729,467 |
| `game/assets/characters/npc_female_01/Superhero_Female_FullBody.gltf` | `215f2af81ad91eecfcee807bad19b541704b800844d997286b78d5dbed7a3b5e` | 31,652 |
| `game/assets/characters/npc_female_01/T_Hair_2_Normal.png` | `172f230aae0d4366c3cfc0402b2e6d1811b11f8487344bff28605eeacac1558d` | 4,710,013 |
| `game/assets/characters/npc_female_01/Superhero_Female_FullBody.bin` | `3a8220a485b33d05d879115a50697728b45a151781106033afb8b8c243fca208` | 990,808 |
| `game/assets/characters/npc_female_01/T_Superhero_Female_Normal.png` | `cf922460b43ccd31e983e34db05514c9d451dd2f9cdd01a843978e797719f859` | 3,940,537 |
| `game/assets/characters/npc_female_01/T_Eye_Normal.png` | `9ed61f7726a54fe346a78b9e5a18905d8e2b88f86235d97f53cd207a26f3f8c7` | 15,099 |
| `game/assets/characters/npc_female_01/T_Superhero_Female_Roughness.png` | `d2beabf2bd0313e32c68dcdbb80dca371a6e994fabf96efa97128bf9f14fa57b` | 3,277,022 |
| `game/assets/characters/npc_variants/candidate_04_albedo.png` | `184cb5e838baad30b24282231924ba198a36a9c9113ff5138f7fee1e415ad269` | 1,802,689 |
| `game/assets/characters/npc_variants/npc_man_v3_albedo.jpg` | `9e32c520df2487060d13e6f35d61f2cee0ce2f50947115e02ba3852b41daeee2` | 2,505,837 |
| `game/assets/characters/npc_variants/candidate_01_albedo.jpg` | `2fb9204a7f6350eb6203238b7f599a1a5887ddb94f90171150391e3c19fa1286` | 1,768,818 |
| `game/assets/characters/npc_variants/candidate_05_albedo.jpg` | `41b6a28fdca967af272aecbf53ac5ec59b3a8fcbaf27a367aaf2ad71ebb6b934` | 267,491 |
| `game/assets/characters/npc_variants/npc_ubc_male_v1_albedo.png` | `b178159d16f16950a61664984fa1168d814f2ab5a634d3d560f5b51b92056747` | 1,842,181 |
| `game/assets/characters/npc_variants/npc_man_v1_albedo.jpg` | `5c6650e964a45786a16ad1f6d4d227387b755abc2d686b6f9c1349c786992e97` | 2,179,493 |
| `game/assets/characters/npc_variants/npc_ubc_male_v2_albedo.png` | `bae551e0e979aa68d4ff8922852f563a48a7f2b1a483fd37191a7ba985699f3d` | 1,759,952 |
| `game/assets/characters/npc_variants/npc_player_v1_albedo.jpg` | `590155ee50135df8bb5208188a371a192df0667c372b2e65258aa7adcfa18461` | 1,698,507 |
| `game/assets/characters/npc_variants/npc_ubc_female_v1_albedo.png` | `a095ca992c7d81583c6c7ce768ef2daa5fbe6184bdc447c4f2db20ff80617166` | 1,734,558 |
| `game/assets/characters/npc_variants/candidate_03_albedo.jpg` | `b91910c403c827813473bf9360b51c6589527e24106f765e7d0ac7dd0199c4e6` | 2,513,255 |
| `game/assets/characters/npc_variants/npc_man_v2_albedo.jpg` | `735d111ab202486259d4e5ed4d64dd55c481a93eb82755b32565b1eecf419d30` | 2,154,808 |
| `game/assets/characters/npc_variants/candidate_02_albedo.jpg` | `cfd7408199f4a7ed268fc9895f84f4426a59598009053d031a4f542241167929` | 1,766,997 |
| `game/assets/characters/npc_variants/npc_player_v2_albedo.jpg` | `1b9607fe2ce0d415bce47eee3e55e11510af9fe24b0e9ba1a6159d7cabf107ae` | 1,686,972 |
| `game/assets/characters/npc_variants/npc_ubc_female_v2_albedo.png` | `8b0c6d553dca26faf55bd3f632855298307badace00fb95807ee099cc4132d98` | 1,708,882 |
| `game/assets/characters/npc_variants/npc_woman_v2_albedo.jpg` | `2cd7f094907cf5d7cacc5e66b867916886d6b0ed107918afbdf32e3bb523f9ed` | 264,760 |
| `game/assets/characters/npc_variants/npc_woman_v3_albedo.jpg` | `8dbae58c74384601ab829dce37f191852b8c3cb499a6a298917ce386d96c09e2` | 281,811 |
| `game/assets/characters/npc_variants/npc_woman_v1_albedo.jpg` | `e573b745e4f21e8e75c11e47754d58a328165f16050a1798fc1c2d1e00e861ce` | 268,044 |
| `game/assets/characters/coastal_residents/npc_woman_Color_d5e58120-e5b6-46ed-9ab2-8c18950c8282.jpg` | `5b417adeb3c65f566a214c0ec4b2bff91dc23c661f9576c2daf375cf800c4a3d` | 183,733 |
| `game/assets/characters/coastal_residents/player_ORM_f6c2b0c4-b8ad-40de-86ad-88a9fd9b397b.jpg` | `808e261126d67e53cb3cd24eed0b76434bad0f24834001e39994cbcbc3171e90` | 653,529 |
| `game/assets/characters/coastal_residents/npc_woman_ORM_d5e58120-e5b6-46ed-9ab2-8c18950c8282.jpg` | `358f27d5b16af06096df3a75af88b44969f13253012febd34da8d9fae47beefe` | 124,861 |
| `game/assets/characters/coastal_residents/player_Color_f6c2b0c4-b8ad-40de-86ad-88a9fd9b397b.jpg` | `edab2b2419e9688cf272fc78355bac09418dd4b316c92c38a185a1758df72303` | 1,118,236 |
| `game/assets/characters/coastal_residents/npc_man.glb` | `2c222771f95e018fb16d70de9a9e8b863f8cbb09a9526bbd0a685910c06c927b` | 2,801,916 |
| `game/assets/characters/coastal_residents/npc_man_NormalGL_96929be6-117b-4395-a0f9-21bc2bf2af60.jpg` | `00fef83e248f1f16d3a5c0d95548b65360f6519ad9a6d395f03f23e539890c87` | 373,712 |
| `game/assets/characters/coastal_residents/npc_woman_NormalGL_d5e58120-e5b6-46ed-9ab2-8c18950c8282.jpg` | `14c38ce1b1674819c0c1c8c1faff056e49e66dff798d5233b18ebec569798f58` | 32,484 |
| `game/assets/characters/coastal_residents/player.glb` | `ea727a3a2714d2cc804e41a14efc6f8a5df1f7d816abf2f54976e115887429aa` | 2,364,000 |
| `game/assets/characters/coastal_residents/npc_man_Color_96929be6-117b-4395-a0f9-21bc2bf2af60.jpg` | `47096d884cbaba077a767a8e8462073e57a1c3b7e51b082a89da82c205ec5a2f` | 1,459,694 |
| `game/assets/characters/coastal_residents/npc_man_ORM_96929be6-117b-4395-a0f9-21bc2bf2af60.jpg` | `c29652c55f82971602bea3b0b1e7efe53e8936f200a1714b7243a4429467ef74` | 730,152 |
| `game/assets/characters/coastal_residents/player_NormalGL_f6c2b0c4-b8ad-40de-86ad-88a9fd9b397b.jpg` | `7208bd7c93966cfc3a2cf9638c2cd929026a41f5e63590b98c1d7e43d749495f` | 346,117 |
| `game/assets/characters/coastal_residents/npc_woman.glb` | `bbef1aba8e35591ffa3f3150dab684e3bb13873b5474779b2792e18193ae99c5` | 606,380 |
| `game/assets/materials/asphalt_street_01/albedo.png` | `71c2181ae903de58d901be627a11a2165e7de4528ad8dfb8cd7c527cb9ba5234` | 4,889,791 |
| `game/assets/materials/asphalt_street_01/ao.png` | `dc18fb13e9f88b618e992bd66473192bf7349b6c6adc5829b0a6403f5a1c25f4` | 2,936,518 |
| `game/assets/materials/asphalt_street_01/normal.png` | `afd35aafce63ed1cf20bc754eb97ee5ac1fe885a769e8c850def12b6a3c1cea3` | 23,103,154 |
| `game/assets/materials/asphalt_street_01/roughness.png` | `cdf1ea08a6da3a820a2210f6dda8430a98ec1266d04966deb03f8c056cb4396d` | 3,075,789 |
| `game/assets/materials/facade_concrete_01/albedo.png` | `cfad2c674b48894c7544ee43484a9568daeced29434064f78393a0a943ea38ea` | 1,223,411 |
| `game/assets/materials/facade_concrete_01/normal.png` | `dcac6ceeb207a34af8c5892097f6c3199a597100f6bfc94d8c3752db8019853e` | 10,922,483 |
| `game/assets/materials/facade_concrete_01/roughness.png` | `31ccb3bf4eabbffeb0d953b78f2f7812943c586dbc4344051c18ad0e21761e0a` | 853,470 |
| `game/assets/materials/concrete_sidewalk_01/albedo.png` | `f4e17872fb828c9de7b85f72883e3f1ae9f1de9498f06535d4238cb0c602f2ab` | 7,079,088 |
| `game/assets/materials/concrete_sidewalk_01/ao.png` | `52107f4f353b91a952241e4f323ff28847aeafd3412bb28b9bfe7bf097a1fe61` | 2,904,924 |
| `game/assets/materials/concrete_sidewalk_01/normal.png` | `636563ad729e56f3203355846fc7101c0f693f6d7a4bf1a22a309d04ab63a3ff` | 22,464,048 |
| `game/assets/materials/concrete_sidewalk_01/roughness.png` | `53c4584c1c8c7a21396b414524e817b35307f5a9b0550af5216ff394d00344ab` | 2,975,501 |
| `game/assets/materials/concrete_sidewalk_01/metallic.png` | `cedbd1f2218ca2477111cd5c85a5b045b4fc88a37ec3ab6e089e76b8d83ecb2f` | 1,585 |
| `game/assets/materials/facade_stucco_01/albedo.png` | `d1c12804d3643714780f7bbd1cf76c7cb94b4d01169826efcefb1a7d4d389380` | 2,675,232 |
| `game/assets/materials/facade_stucco_01/normal.png` | `f67bea6cf27359a163067d2c2db34102d65ebe452372572da8ac329dbc708dbb` | 11,863,789 |
| `game/assets/materials/facade_stucco_01/roughness.png` | `8710837b928d7e0fe562971f8166f6a397fe8b915db09ec6fd121d2dd042a2c5` | 956,578 |
| `game/assets/materials/facade_plaster_01/albedo.png` | `4ca901fe22b63c3847b676f01cccde3a1d22d74aee2701c4c4db33566d0af0ee` | 6,191,996 |
| `game/assets/materials/facade_plaster_01/normal.png` | `873b1da60e9085de212567f953473f2c3f7d194d4d7f99e6d5fb35070ab6507b` | 23,774,780 |
| `game/assets/materials/facade_plaster_01/roughness.png` | `da951808534ab66d63e88175792b9f4a90c2071e5342e5e07d465ca7ab396b10` | 2,131,258 |
| `game/assets/materials/facade_tower_01/albedo.png` | `0dc82a1ba4d044c9ceedabeb3261dd5d9686f81d740eb4e9454215b0cd384f12` | 2,242,028 |
| `game/assets/materials/facade_tower_01/emission.png` | `011c5f1852717e68ed465e1e4d1d73462cd1a3a1e80ca940717e3f67ab5a45ab` | 64,455 |
| `game/assets/materials/facade_tower_01/ao.png` | `0e251924a30a20cd370fe1d3771327730f190546b214670589e9391f2e884f6f` | 829,493 |
| `game/assets/materials/facade_tower_01/normal.png` | `c83475c6898d7fd1dc1244e5d4e793ea4d9345e9fb3c0e972c7c36c8a569d91d` | 7,171,004 |
| `game/assets/materials/facade_tower_01/roughness.png` | `f66ad02ce9b20797e71f016fd29a230c28a50455bd611ecafe96346ecd15009f` | 893,563 |
| `game/assets/materials/facade_tower_01/metallic.png` | `58ba883d611ed285b1952d5505bf0c9708ca6c20da11282f31dfed4c0692340a` | 14,598 |
| `game/assets/materials/asphalt_cracked_01/albedo.png` | `13d5d63ed2149fbde692056f7445cbec700270cecd2043f7c451a03a99789588` | 6,494,708 |
| `game/assets/materials/asphalt_cracked_01/ao.png` | `b0dc213c55161bd4af2d0bad66cb8a54950361b08e9c1fc79f741b5b2fb3c2da` | 2,858,044 |
| `game/assets/materials/asphalt_cracked_01/normal.png` | `aa1ca9d89aa34277c6965b98bbc20dfe6ddc937d0781dc71dd4b9e497a5ee111` | 24,049,354 |
| `game/assets/materials/asphalt_cracked_01/roughness.png` | `9592601f92fa3fd0026d67cbd26e76fc52eb0804fef5b022bd391e86be80895c` | 2,137,984 |
| `game/assets/materials/facade_brick_01/albedo.png` | `0d83352ac98a86d7b74586e24534c6a2e33f8a42b3d48412da63c83697221615` | 4,374,923 |
| `game/assets/materials/facade_brick_01/ao.png` | `05400092d7ed05018c42951529ffe68c6ca183c83bad2131e6c666def1cd6a8b` | 1,298,319 |
| `game/assets/materials/facade_brick_01/normal.png` | `92cbf9d24bb4bf2f4a7a231b30d27e20e8f1a7f18638e98293dead57d69d7698` | 11,715,793 |
| `game/assets/materials/facade_brick_01/roughness.png` | `afbfd428530a7313a60274dfd7107853bfc710beb1bc0aad610cc54fccf82021` | 1,074,905 |
| `game/assets/materials/pavement_pavers_01/albedo.png` | `561fe4864a3128ba354f1dea7ae5a2e8b3910221eb04cc93661d48921b4b435c` | 8,791,594 |
| `game/assets/materials/pavement_pavers_01/ao.png` | `9a8c87391167d06c45ca1491542b2b6f9f0a4bdf27514b623c572d6c555752d9` | 3,110,480 |
| `game/assets/materials/pavement_pavers_01/normal.png` | `b253eb731136517ebad817f3a04162bf0e7b77244499ae599359d63133a29928` | 22,980,953 |
| `game/assets/materials/pavement_pavers_01/roughness.png` | `8ce21899d200186c964cb97165fc2d944e762189eab1737cb1d4fc8d40ecf270` | 2,819,815 |
| `game/assets/audio/weapons/pistol.wav` | `1c0c3fd9aba95571a19ffbafe41d9639529cd98d91c90a6af98b8f5834c70932` | 48,044 |
| `game/assets/audio/weapons/rifle.wav` | `9f4c28da93fbe2b976d67245c2f7c0b9d7457ac5a06ab428daf587e42887c1da` | 57,644 |
| `game/assets/audio/weapons/smg.wav` | `393aea81861684664c150620b4c3e2c5dbf1c4a71e12edc630d8ac172fb3f8de` | 21,164 |
| `game/assets/audio/weapons/shotgun.wav` | `22e05048764749b6569d8e48049f5609819798f621313382cc72a9b5a77c9577` | 57,644 |
| `game/assets/audio/footsteps/sand/sand_6.ogg` | `7498c4e50282acc4e7e0442a9f2e551fae685898f8261152dbc627f04901ddbe` | 8,635 |
| `game/assets/audio/footsteps/sand/sand_4.ogg` | `439ffe4d6fdf38194caf87e103897354756d69607bd4e48cef923e1ade68ee70` | 9,796 |
| `game/assets/audio/footsteps/sand/sand_2.ogg` | `68ba66063efa32b3a83979194582b1420f808cd217ccb5839c382d0e08522e18` | 8,922 |
| `game/assets/audio/footsteps/sand/sand_3.ogg` | `0a526053424687c18735bca107b7234e48aceeb6bf12eec1f182d89aaf792b71` | 8,246 |
| `game/assets/audio/footsteps/sand/sand_5.ogg` | `5eec48117da8fa433963ba06a93f67705f0bbd86ac3f473ab7b3bd120bf55fce` | 8,716 |
| `game/assets/audio/footsteps/sand/sand_1.ogg` | `fe6ec00cbe8790be0f37540cb8db8d245ca062337b121003685b6a96700cd0ae` | 10,440 |
| `game/assets/audio/footsteps/concrete/concrete_6.ogg` | `73bbdfc3d9e891bc1afbab7050de3bd59adf13cf5145ff3fb2f1fa7b251d6d82` | 8,404 |
| `game/assets/audio/footsteps/concrete/concrete_3.ogg` | `6e008bba3c24c6adc20151126768eba8c9259ec9f40b7c0b8399d60a9ca67812` | 8,207 |
| `game/assets/audio/footsteps/concrete/concrete_1.ogg` | `2d85768f04a85b6068f3548b33d6e0b0424c5e62b0941042d593affd3a9555d4` | 8,889 |
| `game/assets/audio/footsteps/concrete/concrete_4.ogg` | `d6949efd0255d50efe4853cc077b18e3ee96b155707ccf4199fd530aaac82d58` | 8,855 |
| `game/assets/audio/footsteps/concrete/concrete_5.ogg` | `075c27afbf29b7771cb01a7bf51530b835e82c56698ca5551318fa0c6b7adb9f` | 8,346 |
| `game/assets/audio/footsteps/concrete/concrete_2.ogg` | `1cdd36f02590d2b968b1dd311334e71db8514d7c276e62ad474d01c26b37d4de` | 8,516 |
| `game/assets/ui/video/intro_source.mov` | `b783ca69612b7ff31dec2aaa11db0edaea6ac98ec4deccd2705a4a46e38c639b` | 32,091,427 |
| `game/assets/ui/video/intro.ogv` | `3517f2cfbabdc6707bb49bbd0520f73e293cbc5c4efd572dab10e91201d8abcd` | 14,932,283 |
| `game/assets/ui/loading/hurricane_supplies.png` | `0112ba811762a9b7df8ed43f46865e5fd359fe1ea0ba2a78b45eea3cf00fba54` | 2,904,760 |
| `game/assets/ui/loading/sheriff_gator.png` | `4d4753b38ca3830e7c01ca4ace22552b8664de088643734645bbc242fffcf595` | 2,893,342 |
| `game/assets/ui/loading/crypto_atm.png` | `1d61ef3e123a4eef180826a5b2e2aa4da3dc2d99e7e92405b9a3142b609deba3` | 2,938,486 |
| `game/assets/ui/loading/suncoast_flood.png` | `69c4a59ffe6410db761ce31dd081f48fcf5cf2bc472477aef375f2403b72909b` | 2,787,811 |
| `game/assets/ui/loading/pawn_crew.png` | `e054fbce4f2250c18051dcf28cd90da523d718abcb116f786d6946309074ff2d` | 2,782,891 |
| `game/assets/ui/loading/airboat_swamp.png` | `ede45c80d615dd0fd348e360280196098ae2b41e379be481a83c03c538963402` | 2,769,111 |
| `game/assets/ui/loading/retirement_scooter.png` | `7fbc7ebe515dfbadeed2bbf63f0efa8cb5e57415af4e5d2dfc01339032668057` | 2,920,129 |
| `game/assets/ui/loading/news_anchor.png` | `8b5dc5d794cfa08df8958f1c357459b49aab24d5e87d1cf8e9cc01842ce8ee47` | 2,651,716 |
| `game/assets/vehicles/coastal_sport_coupe/coastal_sport_coupe_coupe_normal.jpg` | `dcba7ec9c73cc7dc01ce2fa5b83da99fbc8d3c3c89b5459fd286241a1aaaa2e8` | 1,050,375 |
| `game/assets/vehicles/coastal_sport_coupe/coastal_sport_coupe_coupe_metallic-coupe_roughness.png` | `97e11011d7ef606336c712e1db53934f0d38b2998cadc2ea76c94cbe5a6feeea` | 8,576,418 |
| `game/assets/vehicles/coastal_sport_coupe/coastal_sport_coupe_coupe_base_color.jpg` | `05ae4351a16ec1725158235631605becc07cff8d0bd34ee3c4c7c219acfe5b9d` | 2,928,129 |
| `game/assets/vehicles/coastal_sport_coupe/coastal_sport_coupe.glb` | `0da975bc9698a2cd89e1209b87b50f9a2f1892d60b698d7beeb4c2cc78ba42b0` | 13,828,496 |
| `game/assets/vehicles/coastal_sport_coupe/coastal_sport_coupe_traffic.glb` | `05049f30991e85a36d59491f292c2327d571c934c80b233f9dec9dc1ea9348d4` | 179,200 |
| `game/assets/vehicles/coastal_classic_sedan/coastal_classic_sedan.glb` | `8578fbb65ea22998f2f30802a30bd6de8b4537cf0721ee5b1f4da5515af88c0b` | 13,704,148 |
| `game/assets/vehicles/coastal_classic_sedan/coastal_classic_sedan_sedan_normal.jpg` | `d3e149d1b7b3d1936e459473cc940b2fb3d859f3fa6a0990499cbc4c9e65e37c` | 514,059 |
| `game/assets/vehicles/coastal_classic_sedan/coastal_classic_sedan_sedan_metallic-sedan_roughness.png` | `e2e891f07b6054412d025875858407d7be8ab7cc60aef0f2ed4562cc600975b1` | 8,236,243 |
| `game/assets/vehicles/coastal_classic_sedan/coastal_classic_sedan_traffic.glb` | `d6467280d63d6db945b0ede2b260f8a9d806bc56717172b087fccb24462102e6` | 130,484 |
| `game/assets/vehicles/coastal_classic_sedan/coastal_classic_sedan_sedan_texture_08.jpg` | `f67b3ecdd1065d6dbb7877ace752168160bd9991ce6ac413827354aa58d56e10` | 3,826,424 |
