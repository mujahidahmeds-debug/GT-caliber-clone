# Android cloud build

The repository now includes `.github/workflows/android-build.yml`. It is intended to build a debug APK on GitHub Actions so a local PC is not required.

## What the workflow does

1. Checks out the repository with Git LFS payloads and recursive submodules enabled.
2. Installs Java 17 and Android SDK platform/build tools for API 36, configures Godot SDK paths, and creates a throwaway debug keystore for this test build.
3. Runs `tools/validate_android_source.py`.
4. Installs Godot 4.6 stable and its matching export templates.
5. Imports the project and exports the `Android` preset in debug mode.
6. Publishes `dist/vicebound-android-debug.apk` as a 14-day workflow artifact.

The workflow uses the official Godot 4.6 release binaries/templates and the `firebelley/godot-export` GitHub Action. Godot's Android export documentation recommends JDK 17 and requires the matching export templates and Android SDK. See the official Godot 4.6 Android export guide: https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_android.html

## One-time GitHub setup from an Android phone

The connected GitHub integration currently has read-only access to `Hypercho-Dev/GT-caliber-clone`. The source bundle cannot be committed to that upstream repository. Use a personal fork as the VICEBOUND working repository:

1. Open `https://github.com/Hypercho-Dev/GT-caliber-clone` in your phone browser while signed in to GitHub.
2. Tap **Fork**, select your personal account, and create the fork. Keep it private if you prefer; ensure GitHub Actions are enabled for it.
3. In ChatGPT, open **Settings → Plugins / Apps → GitHub**, reconnect or adjust repository access, and grant the connected GitHub integration access to that fork with repository contents write and Actions workflow permissions.
4. Return to this chat. The fork must appear in the connected GitHub repository list before I can commit and trigger the build.

After the workflow is committed, a manual run is available from the fork's **Actions → VICEBOUND Android Debug Build → Run workflow** page. On success, download the `vicebound-android-debug` artifact from the run. This workflow is a debug build only, not a Play Store release.

## Current integration limitation

The connected GitHub integration reports `pull: true` and `push: false` for the original repository, and this session has no GitHub fork/create-repository action. I can edit and package the local working copy, but I cannot create a fork or push the source to GitHub on your behalf with the current permissions. This is an access-control boundary, not a missing code fix.

## Build will still fail if

- Git LFS objects are unavailable to the GitHub Actions checkout.
- The `godot-cpp` submodule cannot be fetched.
- Godot import reveals missing assets or script/resource errors.
- The Android export preset or export templates are incompatible.

A successful APK export is only a build artifact. It is not proof that the game is playable, performant or safe to publish. The APK must still be installed and tested on real Android devices.
