# VICEBOUND Android + Offline Monetization Implementation

## Product decision

VICEBOUND is an **offline-first, single-player Android game**. The campaign, world simulation,
missions, local economy and saves must work with airplane mode enabled. Network access is only
used by optional monetization and platform services.

There is no always-on game server, multiplayer backend, account system, or mandatory login in v1.

## What this patch changes

- Renames the Godot application display name to `VICEBOUND`.
- Changes the main menu title and tagline.
- Starts directly at the main menu instead of the intro-video scene. The supplied ZIP contains
  Git LFS pointer files for large media, including the intro video, so this avoids a known missing
  binary dependency in the current archive.
- Adds the `Monetization` autoload as a provider-neutral boundary.
- Adds a product catalogue and conservative ad-placement policy.
- Adds a provisional Android ARM64 export preset.
- Adds a first-pass mobile HUD input overlay mapped to the existing InputMap actions.
- Defaults Android to the Low graphics tier and bilinear 3D scaling when no explicit/saved choice exists.
- Preserves the existing `SaveManager` / `SaveData` local save architecture.

## Offline guarantees

The game runtime must never wait for any of these to start or continue:
- AdMob initialization or ad fill.
- Google Play Billing connection.
- Purchase verification.
- Analytics.
- Network connectivity.

If an adapter is missing, unavailable, or offline:
- The campaign remains playable.
- The local save system continues to work.
- Ads are not shown.
- New purchases are unavailable until connectivity returns.
- Already verified entitlements should remain usable offline through a signed local entitlement
  cache supplied by the production billing adapter.

The current scaffold intentionally does not fake provider success. It does not show ads or sell
products until real Android provider plugins are integrated.

## Monetization policy

### Advertising
- Rewarded ads are user-initiated only.
- Rewarded cash amount: 500 in-game cash (initial balancing value).
- Interstitial placement is restricted to `mission_break`.
- Minimum interstitial cooldown: 5 minutes.
- Maximum interstitials: 6 per app session.
- No ad during driving, combat, cutscenes, loading, or active missions.
- `Remove Ads` disables forced interstitials and future banner placements. Optional rewarded
  ads may remain available because the player chooses to watch them.

### Google Play products

The product IDs in `scripts/monetization/monetization_catalog.gd` are provisional and must be
created exactly in Google Play Console before release:

| Product ID | Type | Grant |
|---|---|---|
| `vicebound_remove_ads` | Non-consumable | Remove forced ads |
| `vicebound_cash_small` | Consumable | 500 soft currency |
| `vicebound_cash_medium` | Consumable | 1,800 soft currency |
| `vicebound_cash_large` | Consumable | 4,500 soft currency |
| `vicebound_vehicle_pack` | Non-consumable | Premium vehicle entitlement |
| `vicebound_mission_pack` | Non-consumable | Premium mission entitlement |

Suggested test prices are ₹99, ₹49, ₹149, ₹299, ₹199 and ₹249 respectively. These are not
hardcoded into the game. Google Play supplies localized prices and taxes at runtime.

### Purchase security

A client-side `PURCHASED` callback is not sufficient proof of payment.

Production release requirements:
1. Integrate a maintained Godot Google Play Billing plugin compatible with the exact Godot 4.6
   release and Android export pipeline.
2. Send purchase tokens to a serverless verification endpoint.
3. Verify purchases using the Google Play Developer API.
4. Deduplicate transactions by purchase token/order ID before delivering consumables.
5. Acknowledge/consume purchases as required by Google Play Billing.
6. Return a signed entitlement receipt for non-consumable ownership.
7. Cache and verify that signed receipt locally so previously verified non-consumables can remain
   available while the device is offline.
8. Reconcile refunds, revocations and pending purchases the next time the device is online.

The current bridge exposes `Monetization.set_verified_entitlement()` for non-consumable ownership. It does not yet implement consumable delivery or a durable transaction ledger. The billing adapter must add those only alongside server-side verification and persistent idempotency; do not grant currency from an unverified client callback. The bridge itself is not payment verification.

A small serverless endpoint can scale to zero. It is not a game server and does not need to run
continuously. No server is needed for ordinary offline gameplay.

## Android build settings

The provisional preset:
- Package ID: `com.aizudi.vicebound` (provisional; check availability and lock before first
  Play Store publication).
- Architecture: ARM64-v8a.
- Android renderer override: Godot Mobile renderer; desktop renderer selection remains unchanged.
- Immersive mode: enabled.
- Internet and network-state permissions: enabled only to support optional ads and billing.
- Minimum SDK: 23 in this draft; verify the final requirement against the selected Godot plugins.
- Target SDK: 36 in this draft, matching the Google Play requirement for new apps and updates from 31 August 2026.

The app remains playable without internet even though the Android manifest has network permissions.

## Current archive blockers

The uploaded ZIP is not a complete working source export:
- 198 Git LFS entries are pointer files, not their binary payloads.
- Those missing LFS objects represent approximately 707 MB of source assets.
- `engine/godot-cpp` is referenced as a Git submodule but is not populated in this ZIP.
- The archive does not include an Android export preset or Android provider plugins.
- `docs/ASSETS.md` explicitly marks the Hunyuan-derived character models as evaluation-only /
  license review pending. They must not ship until cleared or replaced.
- `CREDITS.md` itself notes an attribution gap for the Tripo coastal-resident base characters.
  Resolve this before commercial distribution.

Obtain the complete repository with `git lfs pull` and
`git submodule update --init --recursive` from a valid upstream clone. Verify the LFS object
hashes and asset provenance before building a release.

## Validation status

A structural Python check (`python tools/validate_android_source.py`) confirms scene resource paths,
touch InputMap action names, Android export preset presence and the recorded LFS pointer count.
It does not parse GDScript, import Godot resources, run game tests or export an APK.

This patch has been prepared by static source editing. Godot, Android SDK, export templates,
AdMob and Billing plugins were not available in the build environment. Therefore:
- No APK has been produced.
- No Godot import or headless test has been run.
- No Android device test has been run.
- No live ad or purchase flow is active.

Next technical gate: restore all LFS assets and submodules, open with the matching Godot 4.6
editor, run the repository's `tools/check.sh`, then export and install a debug ARM64 APK. Only
after that should provider plugins be selected and integrated.
