# VICEBOUND commercial release gate

This checklist is intentionally conservative. The supplied project is not yet cleared for commercial distribution merely because its code is MIT-licensed or its asset policy says CC BY 4.0 by default.

## 1. Asset rights: hard blocker

The asset ledger (`docs/ASSETS.md`) explicitly identifies these assets as evaluation-only / not cleared:

- `game/assets/characters/char_hunyuan.glb`
- `game/assets/characters/char_textured.glb`

The Android export preset excludes `assets/characters/char_hunyuan*` and `assets/characters/char_textured*` so these evaluation assets are not intentionally packaged in the Android build. They remain in the source tree for historical/editor research only. Verify the actual exported PCK contents before release.

`CREDITS.md` records an unresolved attribution gap for the Tripo coastal-resident base characters under `game/assets/characters/coastal_residents/`. The ledger claims paid-user output rights and CC BY 4.0, but the credits file itself says the base characters are not yet listed. Reconcile the original generation records / applicable terms, list each required attribution, and include it in the in-game credits before release.

OpenStreetMap-derived building footprints and road centerlines are ODbL 1.0 data. Keep the attribution in the shipped data and credits. Review the exact database and derivative-database obligations for the final distribution model; do not assume that the ODbL applies only to raw files without legal review.

Third-party plugin and engine licenses must remain with their respective source trees. Do not remove MIT notices or imply that the project's MIT code license grants rights to every third-party asset.

## 2. Brand and intellectual property

- `VICEBOUND` is a working title, not a trademark clearance. Search relevant trademark registries and app stores, obtain legal review, and lock the title before public launch.
- `com.aizudi.vicebound` is a provisional Android application ID. Verify availability and ownership before publishing; package IDs cannot be casually changed after release without creating a separate app identity.
- Replace or remove any remaining internal references that could confuse users or imply affiliation with third-party franchises. The game must ship with independently created names, story, characters, maps, vehicle designs, UI, music and marketing materials.
- Retain the upstream MIT license and copyright notices for reused code. Keep a clear record of modifications and contributors.

## 3. Android release engineering

- Restore and verify every required Git LFS object by SHA-256; the uploaded ZIP has 198 pointer files representing 707,178,848 bytes of missing payload.
- Initialize submodules and verify pinned revisions.
- Run the project's full `tools/check.sh` using the exact Godot version and export templates.
- Inspect the final APK/AAB to confirm that excluded test-only and evaluation-only assets are absent.
- Test on real low-, mid- and high-tier Android hardware; record crashes, FPS, memory, thermal throttling, battery drain, input latency and save integrity.
- Generate a production signing key in a secure owner-controlled keystore. Never use the CI debug key for Play Store release; never commit signing credentials.
- Validate target SDK, billing/ad plugin requirements, Play Console policy and privacy disclosures at release time.

## 4. Monetization, privacy and consumer protection

- Integrate maintained Android ad and Play Billing plugins compatible with the pinned Godot release.
- Use test ad units and license testers until the complete flow passes.
- Implement consent and age-appropriate ad handling as applicable to target markets; publish a privacy policy describing all SDK data collection.
- Verify purchase tokens server-side, deduplicate transaction IDs, acknowledge/consume purchases correctly, handle pending/refunded/revoked purchases and persist offline entitlements securely.
- Do not sell gameplay advantages that make the free offline campaign unreasonably grind-heavy. Show optional rewarded ads only after a clear user action and never during active gameplay.
- Confirm that the game remains playable in airplane mode with all ad and billing SDKs unavailable.

## 5. Store submission

- Final app name, icon, screenshots, trailer and descriptions must be original and match actual gameplay.
- Complete content rating, data safety, ads declaration, target audience, privacy policy, support contact and country-specific disclosures.
- Run internal testing, closed testing if required, crash/ANR review and staged rollout before production.

## Release decision

**Current decision: NO-GO.** Missing LFS payloads, unrun Godot tests, untested Android input/performance, unresolved attribution and absent live billing/ad integrations are release blockers. The current source bundle is a development foundation only.
