# Android touch controls

## Current mapping

| Touch area / button | Existing action | Behaviour |
|---|---|---|
| Left virtual stick | `move_left`, `move_right`, `move_forward`, `move_back` | Analog movement using the same InputMap actions as keyboard/gamepad |
| Drag on right half | Camera mouse-look event | Rotates the current on-foot camera; driving camera support depends on its active input path |
| FIRE | `fire` | Hold to fire |
| AIM | `aim` | Hold to aim |
| JUMP | `jump` | Jump / swim surface action |
| RUN | `sprint` | Hold to sprint |
| USE | `interact` | Interact with nearby world objects |
| R | `reload` | Reload |
| HIT | `melee` | Melee action |
| P | `phone` | Open phone UI |
| WPN | `weapon_next` | Cycle weapon |
| Pause | `pause` | Open or close pause menu |

The minimap is moved to the upper-left and reduced on Android so it no longer occupies the lower-left movement area. Android defaults to the Low graphics tier when no saved or explicit quality choice exists; desktop defaults are unchanged. Mobile scaling uses bilinear upscaling instead of the desktop FSR2 path.

## Input implementation

`game/scripts/ui/mobile_touch_controls.gd` is instantiated by `game/scenes/ui/game_hud.tscn`. It is enabled only when Godot reports the `mobile` or `android` feature tag. It tracks independent touch indices so movement, look and action buttons can be used with multiple fingers. It forwards actions through Godot's Input API rather than calling gameplay methods directly.

## Known limitations before device testing

- The right-side camera drag is forwarded as a synthetic mouse-motion event. Confirm this is accepted by the active camera path on the target Android/Godot combination.
- Verify simultaneous multi-touch, touch cancellation, pause/resume and scene changes. Ensure no action remains stuck after an interrupted gesture.
- Button placement and safe-area margins need validation on 16:9, 20:9 and tablet aspect ratios.
- This is a first-pass control scheme. Vehicle steering, throttle/brake, weapon wheel, swimming dive, look-behind and contextual phone gestures may need dedicated mobile controls after playtesting.
- Touch controls do not make the current Forward+ 3D world performant on mobile. Renderer selection, texture budgets, crowd density, shadow quality and world-streaming limits require device profiling.

## Acceptance tests

1. Launch on Android in landscape; verify the overlay is visible and absent on desktop.
2. Move diagonally and in all four directions; verify release returns the player to idle.
3. Drag the right side while moving; verify the camera moves without moving the player.
4. Hold fire/aim/sprint and tap jump/interact/reload/melee/phone/weapon-cycle.
5. Pause while another finger is moving; resume and verify all controls are released correctly.
6. Interrupt touches with Android notifications, app switching and screen lock; verify no stuck movement or firing.
7. Repeat on a narrow phone and a tablet; check HUD and buttons do not overlap important prompts.
